from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,datetime
repo=Path(sys.argv[1]); crate=Path(sys.argv[2]); label=sys.argv[3]; phase=sys.argv[4]
scratch=Path('/workspace/scratch/joint-scalar-20261115')
files=set((repo/crate).rglob('*.rs'))|set((repo/crate/'examples').glob('*.json'))|{repo/crate/'Cargo.toml'}
for name in [crate/'Cargo.lock',Path('bindings/rust/Cargo.toml'),Path('bindings/rust/Cargo.lock')]:
 if (repo/name).is_file():files.add(repo/name)
files={p for p in files if 'target' not in p.relative_to(repo).parts}
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(repo))+'\n' for p in sorted(files))
(scratch/f'{label}.source.{phase}.sha256').write_text(manifest)
with tarfile.open(scratch/f'{label}.source.{phase}.tar.xz','w:xz') as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(repo)))
base=['cargo','--version']
checks=[('tests',['cargo','test','--locked','--release','--manifest-path',str(crate/'Cargo.toml'),'--all-targets'])]
if phase=='final':
 checks += [('clippy',['cargo','clippy','--locked','--release','--manifest-path',str(crate/'Cargo.toml'),'--all-targets','--','-D','warnings'])]
env=os.environ.copy(); env['PATH']='/home/agent/.cargo/bin:'+env['PATH'];env['CARGO_TARGET_DIR']=f'/workspace/.task-cache/joint-scalar-{label}'
for name,args in checks:
 out=scratch/f'{label}.{phase}.{name}.stdout.log';err=scratch/f'{label}.{phase}.{name}.stderr.log'
 with out.open('wb') as o,err.open('wb') as e:
  result=subprocess.run(args,cwd=repo,env=env,stdout=o,stderr=e)
 receipt={'repo':str(repo),'source_manifest':f'{label}.source.{phase}.sha256','source_manifest_sha256':hashlib.sha256(manifest.encode()).hexdigest(),'phase':phase,'check':name,'argv':args,'exit_code':result.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout':out.name,'stderr':err.name}
 (scratch/f'{label}.{phase}.{name}.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
 if result.returncode:
  print(out.read_text()[-4000:]); print(err.read_text()[-4000:]); sys.exit(result.returncode)
