from pathlib import Path
import subprocess,os,json,datetime,sys,hashlib
root=Path(sys.argv[1]); crate=Path(sys.argv[2]); label=sys.argv[3]; scratch=Path('/workspace/scratch/joint-scalar-20261115')
env=os.environ.copy();env['PATH']='/home/agent/.cargo/bin:'+env['PATH'];env['CARGO_TARGET_DIR']=f'/workspace/.task-cache/joint-scalar-{label}'
paths=[crate/'src/joint.rs',crate/'src/prepared.rs',crate/'src/reduction.rs',crate/'src/bin/hashed-ecdl.rs',crate/'tests/joint_targets.rs',crate/'src/lib.rs']
if label=='crypto':paths += [crate/'tests/joint_addition_diagnostics.rs']
checks=[('fmt',['rustfmt','--check','--edition','2021',*map(str,paths)]),('clippy',['cargo','clippy','--locked','--release','--manifest-path',str(crate/'Cargo.toml'),'--all-targets','--','-D','warnings'])]
if label=='crypto': checks += [('msrv',['cargo','+1.78.0','check','--locked','--manifest-path',str(crate/'Cargo.toml'),'--all-targets'])]
for name,args in checks:
 out=scratch/f'{label}.final.{name}.stdout.log';err=scratch/f'{label}.final.{name}.stderr.log'
 with out.open('wb') as o,err.open('wb') as e:r=subprocess.run(args,cwd=root,env=env,stdout=o,stderr=e)
 receipt={'phase':'final','check':name,'argv':args,'exit_code':r.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout':out.name,'stderr':err.name}
 (scratch/f'{label}.final.{name}.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
 if r.returncode: print(out.read_text()[-3000:]);print(err.read_text()[-3000:]);sys.exit(r.returncode)
