#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export ELAN_TOOLCHAIN=leanprover/lean4:v4.34.1
out=/workspace/scratch/ct54-fp-chain-compatibility-gate-03
mkdir "$out" || exit 2
cd /workspace/cryptanalysis
src=experiments/chained-transfer-reference/fp-chain-checker/lean/ChainAdapter.lean
cp "$src" "$out/source.lean"
sha256sum "$src" > "$out/before.sha256"
lean --version > "$out/lean-version.txt"
printf '%s\n' "$ELAN_TOOLCHAIN" > "$out/explicit-toolchain.txt"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
set +e
timeout 600 bash tools/lean/proof-gate.sh --out "$out/proofs" "$src" > "$out/gate.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/gate.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
sha256sum --check "$out/before.sha256" > "$out/after.txt"
guard=$?
printf '%s\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
