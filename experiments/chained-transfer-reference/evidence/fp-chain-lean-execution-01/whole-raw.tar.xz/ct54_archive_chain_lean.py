from pathlib import Path
import subprocess,json,hashlib,shutil,tarfile,io,lzma
r=Path('/workspace/cryptanalysis');s=Path('/workspace/scratch');study=r/'experiments/chained-transfer-reference';raw=s/'ct54-fp-chain-lean-whole-raw-01';raw.mkdir()
for n in ['ct54-fp-chain-lean-01','ct54-fp-chain-lean-audit-diagnostic-01','ct54-fp-chain-matching-lean-diagnostic-01','ct54-fp-chain-compatibility-gate-03']:shutil.copytree(s/n,raw/n)
for n in ['fp-chain-lean-01','fp-chain-lean-02','fp-chain-lean-03']:shutil.copytree(study/'evidence'/n,raw/n)
for p in sorted(s.glob('ct54*chain*lean*.py')):shutil.copyfile(p,raw/p.name)
for n in ['ct54-fp-chain-lean-01.sh','ct54-fp-chain-lean-audit-diagnostic-01.sh','ct54-fp-chain-matching-lean-diagnostic-01.sh','ct54-fp-chain-compatibility-gate-03.sh']:shutil.copyfile(s/n,raw/n)
for repo,name in [(r,'consumer'),(Path('/workspace/crypto'),'upstream')]:
 dest=raw/(name+'-validator');dest.mkdir()
 for p in ['tools/pcc/pcc.py','tools/lean/proof-gate.sh','tools/lean/AuditAxioms.lean','tools/lean/trusted-native.txt','tools/lean/lean-toolchain']:
  d=dest/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/p,d)
shutil.copyfile(study/'FP_CHAIN_PROOF_COMPATIBILITY.md',raw/'FP_CHAIN_PROOF_COMPATIBILITY.md');claims=json.loads((study/'evidence/fp-chain-lean-03/claims.json').read_text());verdicts=json.loads((study/'evidence/fp-chain-lean-03/local-verdicts.json').read_text());assert len(claims)==len(verdicts)==11 and all(v['verdict']=='pass' for v in verdicts)
for c in claims:
 target=raw/'actual-claims'/Path(c['claim_path']).name;target.parent.mkdir(exist_ok=True);shutil.copyfile(r/c['claim_path'],target)
first=json.loads((study/'evidence/fp-chain-lean-01/actual_c0_first_cover-verdict.json').read_text());second=json.loads((study/'evidence/fp-chain-lean-02/actual_c0_first_cover-verdict.json').read_text());assert first['verdict']==second['verdict']=='fail'
assert 'incompatible header' in next((s/'ct54-fp-chain-lean-audit-diagnostic-01/proofs').glob('*/audit.log')).read_text()
assert 'Unknown constant `Lean.ofReduceBool`' in next((s/'ct54-fp-chain-matching-lean-diagnostic-01/proofs').glob('*/audit.log')).read_text()
for n in ['ct54-fp-chain-lean-01','ct54-fp-chain-compatibility-gate-03']:
 assert (s/n/'gate.exit').read_text().strip()=='0' and (s/n/'guard.exit').read_text().strip()=='0'
 assert '11 thm   0 trusted' in (s/n/'gate.log').read_text()
source=study/'fp-chain-checker/lean/ChainAdapter.lean';sha=hashlib.sha256(source.read_bytes()).hexdigest();assert all(hashlib.sha256((s/n/'source.lean').read_bytes()).hexdigest()==sha for n in ['ct54-fp-chain-lean-01','ct54-fp-chain-compatibility-gate-03'])
files=sorted(p for p in raw.rglob('*') if p.is_file());members={str(p.relative_to(raw)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files};buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(raw)),recursive=False)
data=buf.getvalue();z=lzma.compress(data,preset=9);assert lzma.decompress(z)==data
with tarfile.open(fileobj=io.BytesIO(lzma.decompress(z))) as t:
 assert set(t.getnames())==set(members)
 for n,m in members.items():b=t.extractfile(n).read();assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
out=study/'evidence/fp-chain-lean-execution-01';out.mkdir();(out/'whole-raw.tar.xz').write_bytes(z);(out/'members.json').write_text(json.dumps(members,indent=2)+'\n');(out/'custody.json').write_text(json.dumps(dict(protocol='8f3da8',compatibility_addendum='FP_CHAIN_PROOF_COMPATIBILITY.md frozenBEFOREcorrective03',source_sha256=sha,declarations=11,all_exact_local_bindings='pass',main_gate=dict(compiler='4.35.0',compiled=11,trusted=0,original_exit=0,guard_exit=0),binding03=dict(compiler='4.34.1',auditor='unchangedconsumeroriginal4.34.1',exact_claims=11,local_pass=11,full_compatible_gate=dict(compiled=11,trusted=0,original_exit=0,guard_exit=0)),failure01='exact e36488 FAIL_audit;retaineddiagnostic confirms incompatibleoleanheader',failure02='sameexactclaim FAIL_audit under forced4.35;oldconsumer auditor removedAPIs Lean.ofReduceBool/Lean.trustCompiler/String.trim',same_original_failed_claim_reused=True,verifier_changes=False,source_or_statement_changes_after_first_gate=False,axioms=['propext','Classical.choice','Quot.sound'],formal_boundary='actualcurves/Picard/completion/reducer/chainidentification/jointnorminjectivity remain written/native;conditionaltwo-way inverse not globalgeometry proof',whole_files=len(files),raw_tar_sha256=hashlib.sha256(data).hexdigest(),archive_bytes=len(z),archive_sha256=hashlib.sha256(z).hexdigest(),exact_roundtrip=True,every_member_replayed=True,standing='unsigned local proof/binding evidence,notmainci signature'),indent=2)+'\n')
cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Unsigned newC0T20formalcomponent:ELEVENsameexactdeclarations/main4.35gate11compiled0trusted0exit0guard;additionaloriginalconsumer4.34.1compile+audi EXACTPCCbinding03all11localpass/fullcompatiblegate11/0trusted0exit0guard. Firste36488binding01FAIL_audit incompatibleoleanheader andforced4.35binding02FAIL_audit removedoldAuditorAPIs BOTHretainedfulloriginalverdict/diagnostic/source/toolcopies;frozencompatibilityaddendumBEFORE03;SAMEoriginalfailedclaimreusedwithoutrewrite/allsourcedeclarationhashesunchanged/noverifier/trustmanifestchange. ActualC0coverequations/specialfibres/balancing/constants/nonuniformrecovery/conditionalnormuniqueness/BOTHconditionalinversedirections. ActualcurvesPicardcompletionreducerchainnormalization/jointnorminjectivitybridgesstillwrittennative,formalizationpartial. WHOLEoriginalprooftreeONEstdtarXZ/everymemberrawarchivehash/exactroundtrip;no scientificsignature.']
for p in sorted(out.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(r))]
cl=subprocess.run(cmd,cwd=r,check=True,capture_output=True,text=True).stdout.strip();(s/'ct54-fp-chain-lean.claim').write_text(cl+'\n');print(cl,'files',len(files),'archive',len(z),'source',sha,flush=True)
