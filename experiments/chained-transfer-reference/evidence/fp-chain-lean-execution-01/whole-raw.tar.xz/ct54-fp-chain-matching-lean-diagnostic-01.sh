#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export ELAN_TOOLCHAIN=leanprover/lean4:v4.35.0
out=/workspace/scratch/ct54-fp-chain-matching-lean-diagnostic-01
mkdir "$out" || exit 2
cd /workspace/cryptanalysis
printf '%s\n' "$ELAN_TOOLCHAIN" > "$out/explicit-toolchain.txt"
lean --version > "$out/lean-version.txt"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
set +e
timeout 600 bash tools/lean/proof-gate.sh --out "$out/proofs" experiments/chained-transfer-reference/fp-chain-checker/lean/ChainAdapter.lean > "$out/gate.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/gate.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
exit "$status"
