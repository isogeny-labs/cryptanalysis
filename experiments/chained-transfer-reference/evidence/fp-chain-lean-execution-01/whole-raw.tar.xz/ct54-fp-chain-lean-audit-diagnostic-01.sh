#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
out=/workspace/scratch/ct54-fp-chain-lean-audit-diagnostic-01
mkdir "$out" || exit 2
cd /workspace/cryptanalysis
src=experiments/chained-transfer-reference/fp-chain-checker/lean/ChainAdapter.lean
cp "$src" "$out/source.lean"
cp lean-toolchain "$out/audit-cwd-lean-toolchain"
cp experiments/chained-transfer-reference/fp-chain-checker/lean/lean-toolchain "$out/source-lean-toolchain"
sha256sum "$src" > "$out/before.sha256"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
set +e
timeout 600 bash tools/lean/proof-gate.sh --out "$out/proofs" "$src" > "$out/gate.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/gate.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
sha256sum --check "$out/before.sha256" > "$out/after.txt"
guard=$?
printf '%s\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
