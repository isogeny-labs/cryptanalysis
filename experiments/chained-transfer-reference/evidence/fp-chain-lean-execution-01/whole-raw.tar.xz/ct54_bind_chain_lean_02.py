from pathlib import Path
import sys,importlib.util,subprocess,hashlib,json,shutil,lzma,io,tarfile
r=Path('/workspace/cryptanalysis');p=Path('experiments/chained-transfer-reference/fp-chain-checker/lean/ChainAdapter.lean');s=Path('/workspace/scratch/ct54-fp-chain-lean-01')
assert (s/'gate.exit').read_text().strip()=='0' and (s/'guard.exit').read_text().strip()=='0';assert 'PASS                     11 thm   0 trusted' in (s/'gate.log').read_text()
o=r/'experiments/chained-transfer-reference/evidence/fp-chain-lean-02';o.mkdir()
spec=importlib.util.spec_from_file_location('ct54pcc',r/'tools/pcc/pcc.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
names=['actual_c0_first_cover','actual_c0_reciprocal_cover','actual_repeated_finite_fibre','actual_empty_finite_fibre_and_infinity_targets','completed_degree_two_balanced_accounting','actual_public_constants','nonuniform_component_recovery','inverse_norm_component_recovery','forward_component_normalization','norm_diagram_uniqueness','conditional_two_way_inverse'];claims=[];verdicts=[]
for short in names:
 name='PrimeFieldChain.'+short;found=m.lean_find_declaration([p],name);assert found
 path,statement=found;proof=dict(path=str(path),theorem=name,decl_sha256=hashlib.sha256(statement.encode()).hexdigest())
 cmd=[sys.executable,'tools/pcc/pcc.py','claim','new','--kind','theorem','--claim-type','interpretive','--statement',statement,'--scope','Fixed C0/T20 adapter:actual characteristic101 coefficients and conditional finite-group norm uniqueness/two-way inverse with nonuniform104/85. Actual curves/Picard/completion/reducer/chain normalizations and joint norm injectivity remain explicit written/native bridges;no global inverse isogeny/full formal geometry/scientific signature.','--proof','lean:'+json.dumps(proof)]
 cl=(json.loads((r/'experiments/chained-transfer-reference/evidence/fp-chain-lean-01/claims-partial.json').read_text())[0]['claim_path'] if short=='actual_c0_first_cover' else subprocess.run(cmd,cwd=r,text=True,capture_output=True,check=True).stdout.strip());claims.append(dict(name=name,claim_path=cl,statement=statement,proof=proof));(o/'claims-partial.json').write_text(json.dumps(claims,indent=2)+'\n')
 v=subprocess.run([sys.executable,'tools/pcc/pcc.py','verify',cl,'--json'],cwd=r,text=True,capture_output=True);(o/(short+'-verdict.json')).write_text(v.stdout+v.stderr);assert v.returncode==0,(name,v.stdout,v.stderr);parsed=json.loads(v.stdout);assert parsed['verdict']=='pass';verdicts.append(parsed);print(name,cl,flush=True)
(o/'claims.json').write_text(json.dumps(claims,indent=2)+'\n');(o/'local-verdicts.json').write_text(json.dumps(verdicts,indent=2)+'\n')
shutil.copytree(s,o/'original-gate');Path('/workspace/scratch/ct54-fp-chain-lean-bound-02.json').write_text(json.dumps(claims,indent=2)+'\n')
