#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/workspace/scratch/ct54-fp-chain-static-01-build-cache
cd /workspace/cryptanalysis
out=/workspace/scratch/ct54-fp-chain-static-01
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
set +e
timeout 900 cargo clippy --manifest-path experiments/chained-transfer-reference/fp-chain-checker/Cargo.toml --all-targets -- -D warnings > "$out/clippy.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/clippy.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - <<'PY'
from pathlib import Path
import hashlib,json
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-reference';o=Path('/workspace/scratch/ct54-fp-chain-static-01');before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};changed=[p for p in before if before[p]!=after[p]];baseline=json.loads((o/'old-baseline.json').read_text());oldchanged=[p for p,sha in baseline['non_workflow_inputs'].items() if hashlib.sha256((r/p).read_bytes()).hexdigest()!=sha];workflow=(r/'.github/workflows/chained-transfer-reference.yml').read_bytes()==(s/'evidence/fp-chain-primary-01/five-original-jobs.yml').read_bytes();(o/'after.json').write_text(json.dumps(after,indent=2)+'\n');(o/'guards.json').write_text(json.dumps({'owned_count':len(before),'owned_changed':changed,'old50_changed':oldchanged,'five_job_prefix_byte_exact':workflow},indent=2)+'\n');raise SystemExit(bool(changed or oldchanged or not workflow))
PY
guard=$?
printf '%s\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
