from pathlib import Path
from datetime import datetime,timezone
import sys,json,lzma,hashlib,tarfile,io,shutil,subprocess
kind,run_id,job_id,base,bot=sys.argv[1:];assert kind in ['full','admission'];run_id=int(run_id);job_id=int(job_id);r=Path('/workspace/crypto');c=Path('/workspace/cryptanalysis');s=Path('/workspace/scratch');rs=r/'research/chained_jacobian_transfers_20261110';cs=c/'experiments/chained-transfer-reference';handoff='fp-chain-'+('full' if kind=='full' else 'admission')+'-archive-handoff-01';filename='integration-full-01.tar.xz' if kind=='full' else 'admissions-full-01.tar.xz';prefix='ct54-'+kind
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==bot
for label in ['exact-bot-ff','artifact-after-bot','wiring-after-bot']:assert (s/(prefix+'-'+label+'.exit')).read_text().strip()=='0',label
log=(s/(prefix+'-artifact-job-'+str(job_id)+'.log')).read_bytes();assert b'1 remote objects replayed' in log and bot[:9].encode() in log
manifest_path=rs/'evidence'/handoff/'.artifacts.json';manifest=json.loads(manifest_path.read_text());assert set(manifest['files'])=={filename};original=s/'ct54-chain-full-whole-raw-01.tar.xz' if kind=='full' else cs/'evidence/fp-chain-admissions-01/whole-raw.tar.xz';entry=manifest['files'][filename];assert original.stat().st_size==entry['bytes'] and hashlib.sha256(original.read_bytes()).hexdigest()==entry['sha256']
raw=s/(prefix+'-publication-raw-01');raw.mkdir()
for suffix in ['artifact-jobs.json','artifact-bot.json','bot-fetch-01.txt','bot-fetch-01.exit','exact-bot-ff.txt','exact-bot-ff.exit','artifact-after-bot.txt','artifact-after-bot.exit','wiring-after-bot.txt','wiring-after-bot.exit']:
 src=s/(prefix+'-'+suffix);assert src.exists(),src;shutil.copyfile(src,raw/src.name)
shutil.copyfile(s/(prefix+'-artifact-job-'+str(job_id)+'.log'),raw/'whole-job.log');shutil.copyfile(manifest_path,raw/'canonical-manifest.json');shutil.copyfile('/workspace/scratch/ct54_record_single_archive_publication.py',raw/'original-recorder.py')
for optional in [prefix+'-dirty-preservation.json','ct54-root-'+kind+'-artifact-run.json']:
 if (s/optional).exists():shutil.copyfile(s/optional,raw/optional)
normal=s/('ct54-root-full-handoff-publication-01' if kind=='full' else 'ct54-root-admission-handoff-publication-01');shutil.copytree(normal,raw/'normal-publication')
files=sorted(p for p in raw.rglob('*') if p.is_file());members={str(p.relative_to(raw)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files};b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(raw)),recursive=False)
data=b.getvalue();z=lzma.compress(data,preset=9);assert lzma.decompress(z)==data and len(z)<=65536
with tarfile.open(fileobj=io.BytesIO(lzma.decompress(z))) as t:
 assert set(t.getnames())==set(members)
 for n,m in members.items():d=t.extractfile(n).read();assert len(d)==m['bytes'] and hashlib.sha256(d).hexdigest()==m['sha256']
logz=lzma.compress(log,preset=9);assert lzma.decompress(logz)==log and len(logz)<=65536
meta=dict(kind=kind,at=datetime.now(timezone.utc).isoformat(),run=run_id,job=job_id,conclusion='success',base=base,bot=bot,bot_tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=r,text=True).strip(),exact_changed_paths=3,actual_whole_remote_objects_replayed=1,exact_local_fast_forward=0,artifact_check=0,wiring_check=0,canonical_manifest_commit=bot,canonical_manifest_path=str(manifest_path.relative_to(r)),objects=manifest['files'],S3_object='s3://setec-astronomy-artifacts/store/sha256/'+entry['sha256'][:2]+'/'+entry['sha256'],whole_utf8_log=dict(raw_bytes=len(log),raw_sha256=hashlib.sha256(log).hexdigest(),xz_bytes=len(logz),xz_sha256=hashlib.sha256(logz).hexdigest(),exact_roundtrip=True),whole_files=len(files),raw_tar_sha256=hashlib.sha256(data).hexdigest(),archive_bytes=len(z),archive_sha256=hashlib.sha256(z).hexdigest(),exact_roundtrip=True,every_member_replayed=True,scope='actual publication only;native full147b9f and admission0556d8 unchanged;followupno-op not upload proof',standing='unsigned data custody,not scientific signature')
for repo,study in [(r,rs),(c,cs)]:
 out=study/'evidence'/('fp-chain-'+kind+'-archive-publication-01');out.mkdir();(out/'whole-raw.tar.xz').write_bytes(z);(out/'whole-job.log.xz').write_bytes(logz);(out/'members.json').write_text(json.dumps(members,indent=2)+'\n');(out/'canonical-manifest.json').write_bytes(manifest_path.read_bytes());(out/'custody.json').write_text(json.dumps(meta,indent=2)+'\n')
 cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement','Unsigned ACTUAL'+kind+'wholearchivepublication:trusted-base'+str(run_id)+'/job'+str(job_id)+'SUCCESS/ONEwholeactualremoteobjectreplayedBEFOREnormalbot'+bot+'/parent'+base+'/EXACT3pathsrealmanifestignore+archiveremoval/exactlocalFF0/artifact0/wiring0. Object'+str(entry['bytes'])+'SHA'+entry['sha256']+'matchesintactoriginal. WholeUTF8joblog/standardXZ/rawarchivehash/roundtrip plusWHOLEpublicationtreeONEstdtarXZ/everymemberhash/roundtrip;copiesrootconsumerbyteidentical. Originalnativefull147b9f/admission0556d8unchanged;followupno-opneveruploadproof/no scientificsignature/costclaim.']
 for p in sorted(out.iterdir()):cmd+=['--proof','attestation:'+str(p.relative_to(repo))]
 cl=subprocess.run(cmd,cwd=repo,check=True,capture_output=True,text=True).stdout.strip();(s/(prefix+'-archive-publication-'+repo.name+'.claim')).write_text(cl+'\n');print(repo.name,cl,'archive',len(z),'log',len(log),'logxz',len(logz),flush=True)
