from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json,shutil,os
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-reference';o=Path('/workspace/scratch/ct53-prime-admissions-01');o.mkdir();driver=s/'check-prime-norms.sh';root=Path('/workspace/crypto');records=[]
shutil.copyfile(driver,o/'driver-source.sh')
shim=o/'missing-grep-path';shim.mkdir()
for name in ['bash','git','dirname']:(shim/name).symlink_to(shutil.which(name))
for name,upstream,mutation in [('wrong-head',Path('/workspace/scratch/ct53-wrong-head-crypto'),None),('dirty-new-source',root,s/'norm-checker/src/lib.rs'),('dirty-new-certificate',root,s/'evidence/prime-norm-fibre-identity-01.json'),('missing-grep',root,None)]:
 output=o/('never-allocated-'+name);assert not output.exists();before=None
 if mutation:
  before=mutation.read_bytes();mutation.write_bytes(before+b'\n')
 env=os.environ.copy();env['PATH']=str(shim) if name=='missing-grep' else str(Path.home()/'.cargo/bin')+':'+str(Path.home()/'.elan/bin')+':'+env['PATH']
 started=datetime.now(timezone.utc).isoformat()
 try:run=subprocess.run(['/bin/bash',str(driver),str(upstream),str(output)],cwd=r,env=env,capture_output=True,timeout=60)
 finally:
  if mutation:mutation.write_bytes(before)
 finished=datetime.now(timezone.utc).isoformat();(o/(name+'.log')).write_bytes(run.stdout+run.stderr)
 rec=dict(name=name,original_exit=run.returncode,start=started,finish=finished,output_allocated=output.exists(),upstream=str(upstream),mutation=str(mutation) if mutation else None,restored_byte_exact=mutation.read_bytes()==before if mutation else None)
 records.append(rec);(o/'observations-partial.json').write_text(json.dumps(records,indent=2)+'\n');assert run.returncode==2 and not output.exists(),(name,run.returncode,run.stdout,run.stderr)
 if mutation:assert mutation.read_bytes()==before
(o/'observations.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records,indent=2),flush=True)
