#!/usr/bin/env bash
set -u
export PATH="$HOME/.cargo/bin:$HOME/.elan/bin:$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
out=/workspace/scratch/ct53-prime-lean-01
mkdir "$out" || exit 2
src=/workspace/cryptanalysis/experiments/chained-transfer-reference/norm-checker/lean/PullbackFibres.lean
cp "$src" "$out/source.lean"
sha256sum "$src" > "$out/before.sha256"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
set +e
timeout 600 bash /workspace/crypto/tools/lean/proof-gate.sh --out "$out/proofs" "$src" > "$out/gate.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/gate.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
sha256sum --check "$out/before.sha256" > "$out/after.txt"
guard=$?
printf '%s\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
