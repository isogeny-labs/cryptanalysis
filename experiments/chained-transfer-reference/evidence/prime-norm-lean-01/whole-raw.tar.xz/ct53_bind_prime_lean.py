from pathlib import Path
import sys,importlib.util,subprocess,hashlib,json,shutil
r=Path('/workspace/cryptanalysis');p=Path('experiments/chained-transfer-reference/norm-checker/lean/PullbackFibres.lean');s=Path('/workspace/scratch/ct53-prime-lean-01')
assert (s/'gate.exit').read_text().strip()=='0' and (s/'guard.exit').read_text().strip()=='0'
assert 'PASS                     11 thm   0 trusted' in (s/'gate.log').read_text()
o=r/'experiments/chained-transfer-reference/evidence/prime-norm-lean-01';o.mkdir()
spec=importlib.util.spec_from_file_location('ct53pcc',r/'tools/pcc/pcc.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
names=['cleared_fibre_factorization','image_support_substitution','image_ordinate_substitution','unit_ordinate_recovery','actual_ordinate_normalization','actual_first_normalized_cover','actual_second_normalized_cover','actual_first_degree_drop','actual_second_degree_drop','balanced_completion_accounting','actual_public_inverse_constants']
claims=[];verdicts=[]
for short in names:
 name='PrimeNormPullback.'+short;found=m.lean_find_declaration([p],name);assert found
 path,statement=found;proof=dict(path=str(path),theorem=name,decl_sha256=hashlib.sha256(statement.encode()).hexdigest())
 cmd=[sys.executable,'tools/pcc/pcc.py','claim','new','--kind','theorem','--claim-type','interpretive','--statement',statement,'--scope','Independent prime-norm adapter algebra;exact char101 coefficients/degree drops and conditional unit recovery. Curves/Picard/projective completion/jet bridge and old balanced reducer remain written/native;local Lean is unsigned.','--proof','lean:'+json.dumps(proof)]
 cl=subprocess.run(cmd,cwd=r,text=True,capture_output=True,check=True).stdout.strip();claims.append(dict(name=name,claim_path=cl,statement=statement,proof=proof));(o/'claims-partial.json').write_text(json.dumps(claims,indent=2)+'\n')
 v=subprocess.run([sys.executable,'tools/pcc/pcc.py','verify',cl,'--json'],cwd=r,text=True,capture_output=True);(o/(short+'-verdict.json')).write_text(v.stdout+v.stderr);assert v.returncode==0,(name,v.stdout,v.stderr);parsed=json.loads(v.stdout);assert parsed['verdict']=='pass';verdicts.append(parsed);print(name,cl,flush=True)
(o/'claims.json').write_text(json.dumps(claims,indent=2)+'\n');(o/'local-verdicts.json').write_text(json.dumps(verdicts,indent=2)+'\n')
shutil.copytree(s,o/'original-gate')
Path('/workspace/scratch/ct53-prime-lean-bound.json').write_text(json.dumps(claims,indent=2)+'\n')
