"""One-session Git plumbing: publish immutable local objects through gh REST.

Does not move refs, sign claims, rewrite history, or print credentials.
This is repository management, not a research/benchmark execution harness.
"""
import base64
import os
import urllib.request
import urllib.error
import datetime
import json
import pathlib
import re
import subprocess
import sys
import tempfile

repo, expected, head = sys.argv[1:]
assert re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',repo)
assert all(re.fullmatch(r'[0-9a-f]{40}',s) for s in (expected,head))

def git(*args):
    return subprocess.check_output(['git',*args])

def api(endpoint,body):
    # Keep the inherited credential in memory; never place it in argv or logs.
    req=urllib.request.Request('https://api.github.com/repos/'+repo+'/'+endpoint,
        data=json.dumps(body).encode('utf-8'),method='POST',headers={
            'Authorization':'Bearer '+os.environ['GH_TOKEN'],
            'Accept':'application/vnd.github+json','Content-Type':'application/json',
            'X-GitHub-Api-Version':'2022-11-28','User-Agent':'Codex-exact-checkpoint-transport'})
    try:
        with urllib.request.urlopen(req,timeout=60) as response:return json.load(response)
    except urllib.error.HTTPError as e:
        raw=e.read()
        try:message=json.loads(raw).get('message','HTTP error')
        except (ValueError,AttributeError):message='HTTP error'
        raise RuntimeError('HTTP '+str(e.code)+': '+message) from None

def identity(header):
    m=re.fullmatch(r'(.*) <([^<>]+)> (\d+) ([+-]\d{4})',header)
    assert m,header
    name,email,stamp,offset=m.groups()
    minutes=int(offset[1:3])*60+int(offset[3:])
    if offset[0]=='-':minutes=-minutes
    tz=datetime.timezone(datetime.timedelta(minutes=minutes))
    date=datetime.datetime.fromtimestamp(int(stamp),tz).isoformat()
    return dict(name=name,email=email,date=date)


assert git('rev-parse','HEAD').decode().strip()==head
assert git('rev-parse',head+'^').decode().strip()==expected
raw=git('cat-file','commit',head).decode()
header,message=raw.split('\n\n',1);meta={}
for line in header.splitlines():
 key,_,val=line.partition(' ');meta.setdefault(key,[]).append(val)
assert 'gpgsig' not in meta and meta.get('parent')==[expected]
# The preserved first attempt reached git/trees after every changed blob had
# already been published and SHA-checked. Rebuild only changed directory
# objects bottom-up,using immediate entries rather than a huge base-tree edit.
def entries(tree):
 out=[]
 for row in git('ls-tree','-z',tree).split(b'\0'):
  if not row:continue
  info,path=row.split(b'\t',1);mode,kind,sha=info.decode().split()
  out.append(dict(path=path.decode(),mode=mode,type=kind,sha=sha))
 return out
created=[]
def publish_tree(wanted,previous):
 if wanted==previous:return wanted
 new=entries(wanted);old={x['path']:x for x in entries(previous)} if previous else {}
 for item in new:
  if item['type']=='tree':
   before=old.get(item['path']);parent=before['sha'] if before and before['type']=='tree' else None
   item['sha']=publish_tree(item['sha'],parent)
 got=api('git/trees',dict(tree=new))
 assert got['sha']==wanted,('incremental tree mismatch;no refs moved',wanted,got['sha'])
 created.append(dict(sha=wanted,immediate_entries=len(new)))
 print(json.dumps(dict(tree=wanted,immediate_entries=len(new),refs_moved=False)),flush=True)
 return wanted
previous=git('rev-parse',expected+'^{tree}').decode().strip()
tree=publish_tree(meta['tree'][0],previous)
body=dict(message=message,tree=tree,parents=meta['parent'],author=identity(meta['author'][0]),committer=identity(meta['committer'][0]))
got=api('git/commits',body)
assert got['sha']==head,('exact commit mismatch;no refs moved',head,got['sha'])
print(json.dumps(dict(commit=head,tree=tree,parent=expected,changed_trees=len(created),exact_objects_published=True,refs_moved=False)),flush=True)
