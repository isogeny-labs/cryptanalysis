"""Offline process/I-O fixtures for read-only admission diagnostics; no science."""
from pathlib import Path
import os,subprocess,json
out=Path('/dev/shm/ct232-read-only-admission-entire-metadata-controls');out.mkdir()
mock=out/'mock-bin';mock.mkdir()
(mock/'aws').write_text('''#!/usr/bin/env bash
printf '%s\\0' "$@" >> "$LP_METADATA_CALL_LOG"
case "$*" in
 *"sts get-caller-identity"*)
  if [[ $LP_METADATA_FIXTURE == foreign ]];then printf '{"Account":"000000000000"}\\n';else printf '{"Account":"104186811093"}\\n';fi;;
 *"budgets describe-budget"*)
  if [[ $LP_METADATA_FIXTURE == denied ]];then printf 'AccessDenied: synthetic metadata fixture only\\n' >&2;exit 254;fi
  printf '{"Budget":{"BudgetLimit":{"Amount":"200","Unit":"USD"}}}\\n';;
 *"eks describe-cluster"*)
  if [[ $LP_METADATA_FIXTURE == denied ]];then printf 'AccessDenied: synthetic metadata fixture only\\n' >&2;exit 254;fi
  printf '{"name":"isolab","status":"ACTIVE","endpoint":"https://fixture.invalid"}\\n';;
 *"eks update-kubeconfig"*) printf 'Synthetic metadata configuration fixture only\\n';;
 *) printf 'UNEXPECTED API IN OFFLINE FIXTURE\\n' >&2;exit 99;;
esac
''')
(mock/'kubectl').write_text('''#!/usr/bin/env bash
[[ $1 == get ]] || exit 99
case $2 in
 nodepool.karpenter.sh) printf '{"metadata":{"name":"cpu-spot"},"spec":{"limits":{"cpu":"16","memory":"128Gi"}},"status":{"resources":{}}}\\n';;
 nodes|pods) printf '{"items":[]}\\n';;
 resourcequota) printf '{"items":[{"metadata":{"name":"jobs"},"spec":{"hard":{"requests.cpu":"16","limits.cpu":"16","requests.memory":"128Gi","limits.memory":"128Gi"}},"status":{"used":{}}}]}\\n';;
 *) exit 99;;
esac
''')
for p in mock.iterdir():p.chmod(0o755)
script='/workspace/cryptanalysis/experiments/chained-transfer-lp-presentation-01/admission-01/read-only-01.sh'
pool='/workspace/crypto/scripts/isolab_pool_check.sh'
observations=[]
for name in ['foreign','denied','readable']:
 env=os.environ.copy();env.update({'PATH':str(mock)+':'+env['PATH'],'LP_METADATA_FIXTURE':name,'LP_METADATA_CALL_LOG':str(out/(name+'-entire-aws-argv.paths0'))})
 p=subprocess.run(['bash',script,str(out/name),pool],env=env,capture_output=True,timeout=120)
 (out/(name+'-entire-caller.stdout')).write_bytes(p.stdout);(out/(name+'-entire-caller.stderr')).write_bytes(p.stderr);(out/(name+'-actual.exit')).write_text(str(p.returncode)+'\n');assert p.returncode==0
 result=json.loads((out/name/'diagnostic-only-no-admission.json').read_text());assert result['admitted']is False and result['cloud_build_or_job_submitted']is False and result['lane_charged_and_reserved_accounting']=='unknown'
 calls=(out/(name+'-entire-aws-argv.paths0')).read_bytes();assert b'start-build' not in calls and b'create' not in calls and b'put' not in calls
 if name=='foreign':assert b'budgets'not in calls and b'eks'not in calls and result['existing_identity_matches_lab_account']is False
 if name=='denied':assert result['all_three_original_budget_API_reads_succeeded']is False and result['original_all_tenant_pool_check_fits']is False
 if name=='readable':
  assert result['all_three_original_budget_API_reads_succeeded']is True and result['original_all_tenant_pool_check_fits']is True
  assert len(list((out/name/'all-entire-pool-read-responses').glob('call.*')))==4
 observations.append({'fixture':name,'process_exit':p.returncode,'result':result,'scope':'offline mocked process/I-O control only; no real AWS or Kubernetes query'})
(out/'all-entire-control-observations.json').write_text(json.dumps(observations,indent=2)+'\n')
print(json.dumps({'offline_metadata_controls':3,'all_exact_expected':True,'real_cloud_calls':0}))
