use chained_transfer_lp_historical_01::stream;
use std::{
    error::Error,
    fs::{self, File, OpenOptions},
    io::{BufReader, BufWriter, Write},
};

fn output(path: &str) -> Result<BufWriter<File>, Box<dyn Error>> {
    Ok(BufWriter::new(
        OpenOptions::new().write(true).create_new(true).open(path)?,
    ))
}

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<_> = std::env::args().collect();
    match args.as_slice() {
        [_, mode, public, destination] if mode == "produce" => {
            let mut out = output(destination)?;
            stream::produce_public(&fs::read(public)?, &mut out)?;
            out.flush()?;
            out.get_ref().sync_all()?;
        }
        [_, mode, original, public, certificate, destination] if mode == "replay-primary" => {
            let mut out = output(destination)?;
            stream::verify_primary(&fs::read(original)?, &fs::read(public)?,
                &mut BufReader::new(File::open(certificate)?), &mut out)?;
            out.flush()?;
            out.get_ref().sync_all()?;
        }
        [_, mode, original, control, public, certificate, destination] if mode == "replay-feedback" => {
            let mut out = output(destination)?;
            stream::verify_feedback(&fs::read(original)?, &fs::read(control)?, &fs::read(public)?,
                &mut BufReader::new(File::open(certificate)?), &mut out)?;
            out.flush()?;
            out.get_ref().sync_all()?;
        }
        _ => return Err("usage: historical_certificates produce PUBLIC OUT | replay-primary ORIGINAL PUBLIC CERT OUT | replay-feedback ORIGINAL CONTROL PUBLIC CERT OUT".into()),
    }
    Ok(())
}
