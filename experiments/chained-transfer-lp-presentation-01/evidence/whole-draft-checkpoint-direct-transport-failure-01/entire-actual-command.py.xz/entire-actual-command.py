"""Whole file/GitHub byte custody only; no image, compiler or science process."""
from pathlib import Path
from datetime import datetime,timezone
import base64,hashlib,http.client,json,os,subprocess,sys,urllib.request,urllib.error,urllib.parse
repo='isogeny-labs/cryptanalysis';source='adb8a8519990a3b85bf72267b23e984bdf9a57f2';branch='research/chained-transfer-lp-presentation-20261115'
context=Path('/dev/shm/ct347-whole-clean-published-LP-context-05/context');out=Path('/dev/shm/ct348-entire-clean-context-draft-GitHub-checkpoint');out.mkdir();os.chmod(out,0o700)
(out/'entire-actual-command.py').write_bytes(Path(__file__).read_bytes());token=os.environ['GH_TOKEN'];stage='initial'
def save(name,value):
 (out/name).write_text(json.dumps(value,indent=2)+'\n')
def stamp():return datetime.now(timezone.utc).isoformat()
def api(method,path,payload=None,absent=False):
 data=None if payload is None else json.dumps(payload).encode();req=urllib.request.Request('https://api.github.com'+path,data=data,method=method,headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=30) as response:return response.status,json.loads(response.read())
 except urllib.error.HTTPError as error:
  data=error.read();(out/'entire-last-API-error-body.json').write_bytes(data)
  if absent and error.code==404:return 404,json.loads(data)
  raise
cmd=['tar','--create','--format=posix','--sort=name','--mtime=@0','--owner=0','--group=0','--numeric-owner','--hard-dereference','--pax-option=delete=atime,delete=ctime','--file=-','--directory',str(context),'.']
save('entire-actual-deterministic-archive-command.json',cmd)
def stream(label):
 log=(out/(label+'.stderr')).open('wb');p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=log);return p,log
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/cryptanalysis',text=True).strip()==source
 assert json.loads((context/'build-info.json').read_text())['actual_recipe_checkout_head']==source
 assert (context/'recipe/entire-actual-recipe-checkout-status.txt').stat().st_size==0
 stage='archive-entire-context-prepass';p,log=stream('entire-archive-prepass');sha=hashlib.sha256();size=0
 while True:
  block=p.stdout.read(1024*1024)
  if not block:break
  sha.update(block);size+=len(block)
 assert p.wait()==0;log.close();digest=sha.hexdigest();assert 575000000<size<2*1024**3
 save('actual-complete-archive-prepass.json',dict(at=stamp(),bytes=size,sha256=digest,source=source,scope='deterministic whole context stream; whole member bytes retained locally; no local duplicate TAR created'))
 print('whole archive prepass complete',flush=True)
 tag='chained-transfer-lp-runtime-byte-checkpoint-20261116-'+source[:12];ref='refs/tags/'+tag;url='https://github.com/'+repo+'.git'
 env=os.environ.copy();env['GIT_OPTIONAL_LOCKS']='0';n=int(env.get('GIT_CONFIG_COUNT','0'));env.update({'GIT_CONFIG_COUNT':str(n+1),'GIT_CONFIG_KEY_'+str(n):'http.https://github.com/.extraheader','GIT_CONFIG_VALUE_'+str(n):'AUTHORIZATION: basic '+base64.b64encode(('x-access-token:'+token).encode()).decode(),'GIT_TERMINAL_PROMPT':'0'})
 stage='normal-new-checkpoint-tag'
 q=subprocess.run(['git','ls-remote',url,ref],cwd='/workspace/cryptanalysis',env=env,capture_output=True,timeout=30);(out/'entire-tag-before.txt').write_bytes(q.stdout+q.stderr);assert q.returncode==0 and not q.stdout
 q=subprocess.run(['git','push','--no-force','--porcelain',url,source+':'+ref],cwd='/workspace/cryptanalysis',env=env,capture_output=True,timeout=60);(out/'entire-normal-new-tag-push.txt').write_bytes(q.stdout+q.stderr);assert q.returncode==0
 q=subprocess.run(['git','ls-remote',url,ref],cwd='/workspace/cryptanalysis',env=env,capture_output=True,timeout=30);(out/'entire-tag-after.txt').write_bytes(q.stdout+q.stderr);assert q.returncode==0 and q.stdout.decode().split()[0]==source
 stage='create-draft-byte-checkpoint';status,old=api('GET','/repos/'+repo+'/releases/tags/'+tag,absent=True);assert status==404;save('entire-release-tag-absence.json',old)
 body='Draft byte-custody checkpoint for Chained ECDLP Transfers from PR3877. Prepared from the exact clean published recipe source '+source+'. Consumer PCC99ea57 retains the complete context/normal publication and actual19 byte phases. Pure compiler source2c44ee2e, original baselineb7b919/upstream3d49af7 and guarded Root44a3db remain separate. [pcc:unverified]\n\nThe whole context archive is uploaded as one complete asset; it includes both entire original/pure CI ZIPs and the whole guarded-source TAR, as well as selected baseline/engine/native/compiler/fixture/recipe files. This is a draft persistence checkpoint, not a published scientific release, built OCI image, runtime/ABI/admission qualification, signed PCC verdict or replacement for original scientific S3/NEW28 custody. No Docker, AWS, compiler, science process or paid job was invoked. [pcc:unverified]'
 payload=dict(tag_name=tag,target_commitish=source,name='Chained LP runtime bytes — draft checkpoint 2026-11-16',body=body,draft=True,prerelease=True,make_latest='false');save('entire-exact-create-draft-request.json',payload)
 status,release=api('POST','/repos/'+repo+'/releases',payload);save('entire-actual-draft-release-response.json',release);assert status==201 and release['draft'] is True and release['tag_name']==tag
 release_id=release['id'];print('draft byte checkpoint created',release_id,flush=True)
 asset_name='entire-clean-LP-context-'+source[:12]+'.tar';upload=release['upload_url'].split('{',1)[0];parts=urllib.parse.urlsplit(upload);assert parts.scheme=='https' and parts.netloc=='uploads.github.com' and parts.path=='/repos/'+repo+'/releases/'+str(release_id)+'/assets'
 stage='upload-entire-archive';p,log=stream('entire-archive-upload');conn=http.client.HTTPSConnection(parts.netloc,timeout=120);conn.putrequest('POST',parts.path+'?'+urllib.parse.urlencode({'name':asset_name}));conn.putheader('Authorization','Bearer '+token);conn.putheader('Accept','application/vnd.github+json');conn.putheader('Content-Type','application/x-tar');conn.putheader('Content-Length',str(size));conn.putheader('X-GitHub-Api-Version','2022-11-28');conn.endheaders()
 sent=0;actual_sha=hashlib.sha256();next_progress=64*1024*1024
 while True:
  block=p.stdout.read(1024*1024)
  if not block:break
  conn.send(block);actual_sha.update(block);sent+=len(block)
  if sent>=next_progress:print('whole archive upload bytes',sent,flush=True);next_progress+=64*1024*1024
 assert p.wait()==0;log.close();assert sent==size and actual_sha.hexdigest()==digest
 response=conn.getresponse();raw=response.read();(out/'entire-actual-asset-upload-response.json').write_bytes(raw);assert response.status==201;asset=json.loads(raw);assert asset['size']==size and asset['state']=='uploaded'
 if asset.get('digest'):assert asset['digest']=='sha256:'+digest
 conn.close();print('whole archive upload complete',asset['id'],flush=True)
 stage='whole-remote-byte-replay'
 class StripAuthRedirect(urllib.request.HTTPRedirectHandler):
  def redirect_request(self,req,fp,code,msg,headers,newurl):
   result=super().redirect_request(req,fp,code,msg,headers,newurl)
   if result is not None:
    result.remove_header('Authorization');result.remove_header('authorization')
   return result
 opener=urllib.request.build_opener(StripAuthRedirect)
 request=urllib.request.Request('https://api.github.com/repos/'+repo+'/releases/assets/'+str(asset['id']),headers={'Authorization':'Bearer '+token,'Accept':'application/octet-stream','X-GitHub-Api-Version':'2022-11-28'})
 p,log=stream('entire-local-replay-archive');received=0;remote_sha=hashlib.sha256();next_progress=64*1024*1024
 with opener.open(request,timeout=120) as response:
  assert response.status==200 and 'json' not in response.headers.get('Content-Type','')
  while True:
   block=response.read(1024*1024)
   if not block:break
   local=p.stdout.read(len(block));assert local==block;remote_sha.update(block);received+=len(block)
   if received>=next_progress:print('whole remote replay bytes',received,flush=True);next_progress+=64*1024*1024
 assert p.stdout.read(1)==b'' and p.wait()==0;log.close();assert received==size and remote_sha.hexdigest()==digest
 stage='confirm-still-draft';_,current=api('GET','/repos/'+repo+'/releases/'+str(release_id));save('entire-actual-final-draft-release.json',current);assert current['draft'] is True and any(x['id']==asset['id'] and x['size']==size for x in current['assets'])
 save('actual-complete-draft-byte-checkpoint.json',dict(at=stamp(),repo=repo,source=source,tag=tag,normal_new_tag_push=0,draft_release_id=release_id,draft_release_API_URL=release['url'],draft_release_is_unpublished=True,asset_id=asset['id'],asset_name=asset_name,whole_archive_bytes=size,whole_archive_sha256=digest,actual_entire_upload_bytes=sent,actual_whole_remote_replay_bytes=received,actual_every_remote_byte_equals_local_deterministic_archive=True,original_context_hold=str(context),scope='durable whole draft GitHub byte checkpoint; original S3/NEW28/currentCI/review/merge/runtime/OCI/ABI/admission requirements remain independent; unsigned producer data'))
 print('whole draft checkpoint and remote replay complete',flush=True)
except BaseException as error:
 private=Path('/workspace/scratch/private-ct348-draft-checkpoint-error.txt');private.write_text(type(error).__name__+': '+str(error)+'\n');os.chmod(private,0o600)
 save('actual-failure-state.json',dict(at=stamp(),stage=stage,error_type=type(error).__name__,private_complete_diagnostic=str(private),scope='whole local source context/partial GitHub draft and all prior bytes retained; no cleanup/deletion or automatic retry'))
 print('draft checkpoint transport stopped at '+stage+'; full local context and private diagnostic retained',flush=True);raise SystemExit(1)
