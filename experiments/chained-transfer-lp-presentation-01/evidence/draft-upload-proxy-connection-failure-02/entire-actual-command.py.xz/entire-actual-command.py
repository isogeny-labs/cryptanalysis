"""Distinct corrected byte transport; preserve existing draft/tag, no science."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,urllib.request,urllib.error,urllib.parse
repo='isogeny-labs/cryptanalysis';source='adb8a8519990a3b85bf72267b23e984bdf9a57f2';release_id=446932614
context=Path('/dev/shm/ct347-whole-clean-published-LP-context-05/context');old=Path('/dev/shm/ct348-entire-clean-context-draft-GitHub-checkpoint');out=Path('/dev/shm/ct349-complete-draft-assets-proxy-transport');out.mkdir();os.chmod(out,0o700)
(out/'entire-actual-command.py').write_bytes(Path(__file__).read_bytes());token=os.environ['GH_TOKEN'];stage='initial';user_agent='Chained-ECDLP-byte-checkpoint/1'
def stamp():return datetime.now(timezone.utc).isoformat()
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
def api(method,path,payload=None):
 raw=None if payload is None else json.dumps(payload).encode();req=urllib.request.Request('https://api.github.com'+path,data=raw,method=method,headers={'Authorization':'Bearer '+token,'User-Agent':user_agent,'Accept':'application/vnd.github+json','Content-Type':'application/json','X-GitHub-Api-Version':'2022-11-28'})
 with urllib.request.urlopen(req,timeout=30) as response:return json.loads(response.read())
class HashingReader:
 def __init__(self,reader,label):self.reader=reader;self.sha=hashlib.sha256();self.count=0;self.next_progress=64*1024*1024;self.label=label
 def read(self,n=-1):
  data=self.reader.read(n)
  if data:
   self.sha.update(data);self.count+=len(data)
   if self.count>=self.next_progress:print(self.label+' bytes '+str(self.count),flush=True);self.next_progress+=64*1024*1024
  return data
class StripAuthRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  result=super().redirect_request(req,fp,code,msg,headers,newurl)
  if result is not None:result.remove_header('Authorization');result.remove_header('authorization')
  return result
opener=urllib.request.build_opener(StripAuthRedirect)
tar_command=json.loads((old/'entire-actual-deterministic-archive-command.json').read_text());prepass=json.loads((old/'actual-complete-archive-prepass.json').read_text());save('entire-original-complete-context-prepass.json',prepass);save('entire-actual-deterministic-archive-command.json',tar_command)
def archive_stream(label):
 log=(out/(label+'.stderr')).open('wb');p=subprocess.Popen(tar_command,stdout=subprocess.PIPE,stderr=log);return p.stdout,p,log
source_path=Path('/dev/shm/ct304-complete-guarded-runtime-source-bytes-01/entire-guarded-file-snapshot.tar')
items=[dict(name='entire-guarded-source-b441b4375616.tar',bytes=39331840,sha256='b441b4375616df79da9b879dd3d1fc04b8f31ae81b0d2c68c98833c3077fb7b8',file=source_path),dict(name='entire-clean-LP-context-'+source[:12]+'.tar',bytes=prepass['bytes'],sha256=prepass['sha256'],file=None)]
results=[]
try:
 stage='inspect-existing-unpublished-draft';release=api('GET','/repos/'+repo+'/releases/'+str(release_id));save('entire-existing-draft-before.json',release);assert release['draft'] is True and release['tag_name']=='chained-transfer-lp-runtime-byte-checkpoint-20261116-'+source[:12] and not release['assets']
 body='Draft byte-custody checkpoint from exact published recipe '+source+'. Current transport is incomplete: the first direct upload connection was refused before a confirmed asset; full source and archive prepass/failure are preserved in PCC5ef5dc. No whole-context upload is yet claimed. [pcc:unverified]\n\nThe corrected transport uses the existing workspace HTTPS proxy and repository identity, preserving the whole source archive first and then the complete context, with full remote byte comparisons. Clean context/source publication is PCC99ea57. Native compiler2c44ee2e, baselineb7b919/upstream3d49af7 and guarded Root44a3db remain separate. Original scientific S3/NEW28/runtime/OCI/ABI/admission/CI/review/merge requirements remain open. No image/native science or paid job. This release remains a draft. [pcc:unverified]'
 save('entire-corrected-draft-body-request.json',dict(body=body));save('entire-corrected-draft-body-response.json',api('PATCH','/repos/'+repo+'/releases/'+str(release_id),dict(body=body)))
 upload=release['upload_url'].split('{',1)[0];parts=urllib.parse.urlsplit(upload);assert parts.scheme=='https' and parts.netloc=='uploads.github.com' and parts.path=='/repos/'+repo+'/releases/'+str(release_id)+'/assets'
 for index,item in enumerate(items):
  name=item['name'];stage='whole-asset-upload-'+str(index);size=item['bytes'];digest=item['sha256']
  if item['file'] is None:raw,p,log=archive_stream('entire-context-upload')
  else:raw=item['file'].open('rb');p=None;log=None;assert item['file'].stat().st_size==size
  hashed=HashingReader(raw,'upload '+name);request=urllib.request.Request(upload+'?'+urllib.parse.urlencode({'name':name}),data=hashed,method='POST',headers={'Authorization':'Bearer '+token,'User-Agent':user_agent,'Accept':'application/vnd.github+json','Content-Type':'application/x-tar','Content-Length':str(size),'X-GitHub-Api-Version':'2022-11-28'})
  with urllib.request.urlopen(request,timeout=120) as response:
   response_bytes=response.read();(out/('entire-asset-'+str(index)+'-upload-response.json')).write_bytes(response_bytes);assert response.status==201;asset=json.loads(response_bytes)
  raw.close()
  if p is not None:assert p.wait()==0;log.close()
  assert hashed.count==size and hashed.sha.hexdigest()==digest and asset['size']==size and asset['state']=='uploaded'
  if asset.get('digest'):assert asset['digest']=='sha256:'+digest
  print('complete whole asset uploaded '+str(asset['id']),flush=True)
  stage='whole-remote-byte-replay-'+str(index)
  if item['file'] is None:local,p,log=archive_stream('entire-local-context-replay')
  else:local=item['file'].open('rb');p=None;log=None
  remote_sha=hashlib.sha256();received=0;next_progress=64*1024*1024;request=urllib.request.Request('https://api.github.com/repos/'+repo+'/releases/assets/'+str(asset['id']),headers={'Authorization':'Bearer '+token,'User-Agent':user_agent,'Accept':'application/octet-stream','X-GitHub-Api-Version':'2022-11-28'})
  with opener.open(request,timeout=120) as response:
   assert response.status==200 and 'json' not in response.headers.get('Content-Type','')
   while True:
    block=response.read(1024*1024)
    if not block:break
    assert local.read(len(block))==block;remote_sha.update(block);received+=len(block)
    if received>=next_progress:print('whole replay '+name+' bytes '+str(received),flush=True);next_progress+=64*1024*1024
  assert local.read(1)==b'';local.close()
  if p is not None:assert p.wait()==0;log.close()
  assert received==size and remote_sha.hexdigest()==digest
  receipt=dict(at=stamp(),draft_release_id=release_id,asset_id=asset['id'],asset_name=name,whole_bytes=size,sha256=digest,actual_entire_upload_bytes=hashed.count,actual_entire_remote_replay_bytes=received,every_remote_byte_matches_original=True,scope='complete unsigned draft GitHub byte custody, not original scientific S3/NEW28 or image/runtime qualification')
  results.append(receipt);save('actual-complete-asset-'+str(index)+'-whole-replay.json',receipt);print('complete remote byte replay '+name,flush=True)
 stage='final-still-draft-confirmation';current=api('GET','/repos/'+repo+'/releases/'+str(release_id));save('entire-actual-final-draft-release.json',current);assert current['draft'] is True and len(current['assets'])==2
 save('actual-complete-whole-draft-checkpoint.json',dict(at=stamp(),repo=repo,source=source,tag=release['tag_name'],draft_release_id=release_id,draft_release_API_URL=release['url'],draft_release_remains_unpublished=True,whole_assets=results,actual_context_members=309,original_context_hold=str(context),prior_failure='PCC-20261116-5ef5dc; direct connection refused; existing proxy/identity reused',scope='entire source and context asset bytes persisted and remotely replayed; original scientific S3/NEW28/currentCI/review/merge/runtimeGit/checkpoint/OCI/ABI/admission remain separate'))
 print('complete whole source/context draft checkpoint retained and replayed',flush=True)
except BaseException as error:
 private=Path('/workspace/scratch/private-ct349-draft-checkpoint-error.txt');private.write_text(type(error).__name__+': '+str(error)+'\n');os.chmod(private,0o600)
 save('actual-failure-state.json',dict(at=stamp(),stage=stage,error_type=type(error).__name__,private_complete_diagnostic=str(private),completed_whole_asset_replays=results,scope='all local contexts and actual draft/assets/partial outputs retained; no deletion or automatic retry'))
 print('corrected draft byte transport stopped at '+stage+'; full local bytes and private diagnostic retained',flush=True);raise SystemExit(1)
