#!/usr/bin/env bash
# Distinct file/Git repair of the retained failed public source preparation.
set -euo pipefail
if [[ ${1:-} == --worker ]];then
 [[ $# == 5 ]] || exit 2
 expanded=$2;runtime=$3;list=$4;tracked=$5;repo=$runtime/cryptanalysis
 while IFS= read -r relative;do
  input=$expanded/cryptanalysis/$relative
  target=$repo/$relative
  for depth in {1..32};do
   [[ $target == "$repo/"* || $target == "$runtime/crypto/"* ]]
   [[ $target != "$repo/.git" && $target != "$repo/.git/"* ]]
   if [[ -L $target ]];then target=$(realpath -m "$target");continue;fi
   if [[ ! -e $target && $target == "$repo/"* ]];then
    rel=${target#"$repo/"}
    entry=$(git -C "$repo" ls-files --stage -- "$rel")
    if [[ -n $entry ]];then
     read -r mode oid rest <<< "$entry"
     if [[ $mode == 120000 ]];then
      git -C "$repo" checkout --ignore-skip-worktree-bits HEAD -- "$rel"
      continue
     fi
     [[ $mode == 100644 || $mode == 100755 ]]
     [[ $(git -C "$repo" hash-object --no-filters "$input") == "$oid" ]]
     printf '%s\n' "$rel" >> "$tracked"
    fi
   fi
   break
  done
  [[ ! -L $target && $target == "$runtime/"* ]]
  if [[ -e $target ]];then
   [[ -f $target ]]
   cmp "$input" "$target"
  else
   mkdir -p "$(dirname -- "$target")"
   ln "$input" "$target"
  fi
  printf '%s\t%s\n' "$relative" "${target#"$runtime/"}"
 done < "$list"
 exit 0
fi
[[ $# == 4 ]] || exit 2
old=$(realpath -e "$1")
expanded=$(realpath -e "$2")
list=$(realpath -e "$3")
out=$(realpath -m "$4")
[[ ! -e $out ]]
mkdir "$out"
cp "$0" "$out/entire-actual-repair-command.sh"
finish(){ local code=$?;trap - EXIT;printf '%s\n' "$code" > "$out/original.exit";date -u +%FT%TZ > "$out/finish.txt";exit "$code"; }
trap finish EXIT
date -u +%FT%TZ > "$out/start.txt"
phase(){
 local name=$1 code;shift
 jq --null-input --args '$ARGS.positional' -- "$@" > "$out/$name.argv.json"
 set +e
 (ulimit -v 2097152;exec timeout --signal=TERM --kill-after=5s 120 "$@") > "$out/$name.stdout" 2> "$out/$name.stderr"
 code=$?;set -e
 printf '%s\n' "$code" > "$out/$name.exit"
 printf '%s %s\n' "$name" "$code" >> "$out/all-actual-repair-phases.txt"
 return "$code"
}
# Keep the entire old failed runtime/Git tree byte-exact. New files use separate
# directories; immutable object/source files may share content via hardlinks.
phase preserve-before-and-create-separate-repair-tree cp --archive --link "$old" "$out/runtime"
repo=$out/runtime/cryptanalysis
phase exact-native-source git -C "$repo" rev-parse HEAD
[[ $(cat "$out/exact-native-source.stdout") == 2c44ee2ebb0be9b5fc0375818cc18924cef82c41 ]]
phase require-original-real-source-ancestor git -C "$repo" merge-base --is-ancestor HEAD refs/remotes/origin/research/chained-transfer-lp-presentation-20261115
phase separate-mutable-Git-metadata python3 /workspace/scratch/ct360_separate_repair_git_metadata.py "$old" "$out/runtime" "$out"
phase materialize-original-canonical-ignore-metadata git -C "$repo" sparse-checkout reapply
: > "$out/entire-canonical-tracked-data-targets.txt"
phase preserve-links-and-materialize-whole-targets bash "$out/entire-actual-repair-command.sh" --worker "$expanded" "$out/runtime" "$list" "$out/entire-canonical-tracked-data-targets.txt"
phase canonical-tracked-targets-in-real-status bash -c 'cd "$1" && exec git update-index --no-skip-worktree --stdin < "$2"' _ "$repo" "$out/entire-canonical-tracked-data-targets.txt"
phase all-original1605-source-bytes bash -c 'cd "$1" && exec sha256sum --check experiments/chained-transfer-relation-diagnostics-02/reference-02.sha256' _ "$repo"
phase all-pure50-source-bytes bash -c 'cd "$1" && exec sha256sum --check experiments/chained-transfer-lp-presentation-01/historical-01/source-01.sha256' _ "$repo"
phase all-population12-source-bytes bash -c 'cd "$1" && exec sha256sum --check experiments/chained-transfer-lp-presentation-01/population-01/source-01.sha256' _ "$repo"
phase actual-clean-source-status env GIT_OPTIONAL_LOCKS=0 git -C "$repo" status --porcelain --untracked-files=all
[[ ! -s $out/actual-clean-source-status.stdout ]]
phase original-unpushed-commit-count git -C "$repo" rev-list --count HEAD --not --remotes
[[ $(cat "$out/original-unpushed-commit-count.stdout") == 0 ]]
phase exact-committed-RESUME git -C "$repo" show HEAD:.resume/RESUME.md
phase entire-committed-RESUME-equality cmp "$repo/.resume/RESUME.md" "$out/exact-committed-RESUME.stdout"
phase original-failed-runtime-byte-preservation python3 -c 'from pathlib import Path;import sys,json,hashlib,os;o=Path(sys.argv[1]);xs=json.loads(Path(sys.argv[2]).read_text());assert all((os.readlink(o/x["path"])==x["symlink"] if "symlink" in x else (o/x["path"]).stat().st_size==x["bytes"] and hashlib.sha256((o/x["path"]).read_bytes()).hexdigest()==x["sha256"]) for x in xs);print("all original failed-tree bytes and symlinks unchanged",len(xs))' "$old" "$out/entire-original-failed-runtime-byte-inventory.json"
printf '%s\n' 'Independent public native-source2c Git materialization and whole canonical data targets, original1605/50/12 guards/clean source/unpushed0/committed RESUME only; original failed runtime preserved. No checkpoint/AWS/native science/image/ABI/admission qualification.' > "$out/scope.txt"
