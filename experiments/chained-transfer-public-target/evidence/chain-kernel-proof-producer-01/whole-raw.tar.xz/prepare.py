"""I/O freezing and original Lean gate launch, not a proof verifier."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,subprocess,sys
r=Path('/workspace/cryptanalysis');s=r/'experiments/chained-transfer-public-target';attempt=sys.argv[1]
mode=sys.argv[2] if len(sys.argv)>2 else 'original-consumer-4.35'
assert mode in ('original-consumer-4.35','producer-4.35','consumer-4.34.1')
toolchain='leanprover/lean4:v4.34.1' if mode=='consumer-4.34.1' else 'leanprover/lean4:v4.35.0'
gate='/workspace/crypto/tools/lean/proof-gate.sh' if mode=='producer-4.35' else 'tools/lean/proof-gate.sh'
o=Path('/workspace/scratch')/('ct61-chain-kernel-lean-'+attempt);o.mkdir()
files=[s/'chain-kernels/lean/ChainKernels.lean',s/'chain-kernels/lean/lean-toolchain',r/'tools/lean/proof-gate.sh',r/'tools/lean/AuditAxioms.lean',r/'tools/lean/trusted-native.txt',r/'tools/lean/trusted-native.txt.sha256',r/'tools/pcc/pcc.py',r/'pcc/keyring.json']
files+=[Path('/workspace/crypto/tools/lean/proof-gate.sh'),Path('/workspace/crypto/tools/lean/AuditAxioms.lean')]
files=[p for p in files if p.is_file()]
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
for p in files:
 d=o/'source'/p.relative_to('/workspace');d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
(o/'before.json').write_text(json.dumps(before,indent=2)+'\n')
plan=dict(protocol='a94132 beforecode;29830anative;formalplanbeforeLean',mode=mode,question='geometrickerneltypeequations/free4/sameproductcollapse',prediction='3 named declarations compile and original axiom audit accepts with0trusted;actual divisor/Picard/solver/cover bridge remains written/native',command=['bash',gate,'--out',str(o/'proofs'),'experiments/chained-transfer-public-target/chain-kernels/lean/ChainKernels.lean'],ELAN_TOOLCHAIN=toolchain,timeout_s=900,falsification='original compile/audit nonzero or changed sourceguard;retain whole failure then freeze only proof correction without weakening statements',scope='local formal development,not execution proof/full geometric formalization/benchmark')
(o/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
script='''#!/usr/bin/env bash
set -u
export PATH="$HOME/.elan/bin:$HOME/.cargo/bin:$PATH"
export ELAN_TOOLCHAIN=leanprover/lean4:v4.35.0
cd /workspace/cryptanalysis
out=OUTPUT
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/start.txt"
lean --version > "$out/lean-version.txt" 2>&1
set +e
timeout 900 bash tools/lean/proof-gate.sh --out "$out/proofs" experiments/chained-transfer-public-target/chain-kernels/lean/ChainKernels.lean > "$out/native.log" 2>&1
status=$?
printf '%s\\n' "$status" > "$out/native.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/finish.txt"
python3 - "$out" <<'GUARD'
from pathlib import Path
import hashlib,json,sys
o=Path(sys.argv[1]);before=json.loads((o/'before.json').read_text());after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};changed=[p for p in before if before[p]!=after[p]]
(o/'after.json').write_text(json.dumps(after,indent=2)+'\\n');(o/'guards.json').write_text(json.dumps(dict(count=len(before),changed=changed),indent=2)+'\\n');raise SystemExit(bool(changed))
GUARD
guard=$?
printf '%s\\n' "$guard" > "$out/guard.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
exit "$guard"
'''.replace('OUTPUT',str(o)).replace('leanprover/lean4:v4.35.0',toolchain).replace('bash tools/lean/proof-gate.sh','bash '+gate)
launcher=Path(str(o)+'.sh');launcher.write_text(script);shutil.copyfile(launcher,o/'original-command.sh');shutil.copyfile(__file__,o/'prepare.py');print(launcher,flush=True)
