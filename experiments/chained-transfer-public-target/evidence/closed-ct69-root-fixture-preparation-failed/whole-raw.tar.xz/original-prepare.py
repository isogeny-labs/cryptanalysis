"""Freeze original binary/source/fixture bytes,then run the original exact test."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
o=Path('/workspace/scratch/ct68-original-root-fixture-regression-01');o.mkdir()
old=Path('/workspace/scratch/ct55-g3-root-fixture-diagnostic-01');before=json.loads((old/'before.json').read_text());assert len(before)==2133
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
binary=Path('/workspace/scratch/ct55-g3-root-regression-01-build-cache/release/deps/crypto_lib-0f5740d1cfe22c09');digest=hashlib.sha256(binary.read_bytes()).hexdigest();assert digest=='82029f639d326548a7d44ea0f55477880f0c50cf358edeec3a6827f22591a9bd'
fixture=Path('/workspace/crypto/research/curve25519_f1_targetwalk_20261108/sessions/k20-s0/records.jsonl');h=hashlib.sha256(fixture.read_bytes()).hexdigest();assert h=='8970667e2f18587eeb08d033123dab029b94042ac5c07c870b08988f1ee5b738'
before[str(binary)]=digest;before[str(fixture)]=h;assert len(before)==2135
(o/'before.json').write_text(json.dumps(before,indent=2)+'\n');shutil.copyfile(__file__,o/'prepare.py')
(o/'plan.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),protocol='708cb8/2aee published beforedataworkflow and targetedrun',command=json.loads((old/'plan.json').read_text())['command'],timeout_s=120,original_binary_sha256=digest,original_binary_bytes=binary.stat().st_size,guard_count=2135,source='same2133 originalcompiled source/input guards unchanged plus exactoriginalbinary+authenticfixture;historicalwhole source remains in originalclosedrootcapture;not recopied',fixture='genuineoriginalread43516010720/132198018704/14081195285/originallocalverify0/wholeZIP+members retained',scope='exact formerlyfailing original metadata-fixture regression only;not globalroot acceptance or performance'),indent=2)+'\n')
text=(old/'original-command.sh').read_text().replace('out=/workspace/scratch/ct55-g3-root-fixture-diagnostic-01','out=/workspace/scratch/ct68-original-root-fixture-regression-01').replace('timeout 60 ','timeout 120 ')
launcher=Path(str(o)+'.sh');launcher.write_text(text);shutil.copyfile(launcher,o/'original-command.sh');print(launcher,len(before),flush=True)
