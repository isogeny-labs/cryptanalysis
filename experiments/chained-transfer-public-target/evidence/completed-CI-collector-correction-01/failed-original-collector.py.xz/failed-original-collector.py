"""Native log/API custody and calls to the unchanged PCC tooling only."""
from pathlib import Path
from datetime import datetime, timezone
import json, re, shutil, subprocess, lzma, hashlib, importlib.util, sys
r=Path('/workspace/cryptanalysis'); s=r/'experiments/chained-transfer-public-target'
def claim(statement,dest):
    cmd=['python3','tools/pcc/pcc.py','claim','new','--kind','statement','--claim-type','data','--statement',statement]
    for p in sorted(dest.iterdir()):
        if p.is_file(): cmd+=['--proof','attestation:'+str(p.relative_to(r))]
    print(subprocess.check_output(cmd,cwd=r,text=True).strip(),flush=True)
def records(log):
    rows=[]
    for line in log.splitlines():
        m=re.search(r'\b(N4_[A-Z0-9_]+) (\{.*\})$',line)
        if m: rows.append(dict(kind=m[1],data=json.loads(m[2])))
    return rows
canonical=lambda x: sorted(json.dumps(t,sort_keys=True,separators=(',',':')) for t in x)
a=Path('/workspace/scratch/ct59-two-primary-native-01'); b=Path('/workspace/scratch/ct59-two-primary-native-02')
for f in ['compile.exit','native.exit','guard.exit']: assert (b/f).read_text().strip()=='0'
guard=json.loads((b/'guards.json').read_text()); assert guard==dict(count=2318,changed=[])
old=records((a/'native.log').read_text()); new=records((b/'native.log').read_text())
assert len(new)==4 and canonical(new)==canonical(old)
assert '1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in (b/'native.log').read_text()
d=s/'evidence/two-primary-acceptance-02'; d.mkdir()
for f in ['guards.json','plan.json','original-command.sh','start.txt','finish.txt']: shutil.copyfile(b/f,d/f)
(b/'all-native-records.json').write_text(json.dumps(new,indent=2)+'\n')
(d/'all-native-records.json.xz').write_bytes(lzma.compress((b/'all-native-records.json').read_bytes()))
(d/'observation.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),native='02',all_four_records_equal_partial_capture_01=True,partial01_preserved='1311d9',full_selected_dependency_capture=2318,all_guards_unchanged=True,original_native_exit=0,one_unfiltered_test=True,scope='actual cofactor4 group and map tables; written Ciani order bridge; no geometric basis/kernel census or cost claim'),indent=2)+'\n')
claim('Unverified execution observations: actual q223 two-primary native02 compiles/test0; one unfiltered test, all2318 selected dependency hashes unchanged, all4 JSON records byte-equivalent as JSON to preserved partialcapture01/1311d9. Original Picard gives four actual cofactor classes with orders1,2,4,4 (C4), whereas original independent E(K)[2] is C2xC2; all16tables,64Jacassociativity and bothNorm/Phi homomorphisms/compositions checked. Rational kernels/images2 each, nonzero primeellPhiG separatelychecked. #J=4ell and Frobenius polynomial use written CianiResisogeny; geometric2torsion basis/fullkernelcensus notcomputed. No speed/fullformal/signedexecution claim.',d)
o=Path('/workspace/scratch/ct59-completed-own-CI-raw-01'); source='68febd868af86da068d0ef906065a57d9faaa2c5'
rows={}; verdicts=[]; jobs=[]
for label,run,job,marker in [('completed',43445565169,131953969628,'Completed-descent replay complete:'),('V2',43445564907,131953968270,'Completed V2/rho replay complete:'),('P1',43445564904,131953968746,'Public-target N4 replay complete:'),('PCC',43445565067,131953969401,'Verify all claims')]:
    api=json.loads((o/(label+'-jobs-api.json')).read_text())['structuredContent']['jobs']
    target=[x for x in api if x['id']==job]; assert len(target)==1
    j=target[0]; assert (j['run_id'],j['status'],j['conclusion'])==(run,'completed','success')
    log=json.loads((o/(label+'-log-api.json')).read_text())['structuredContent']['content']
    assert source in log and marker in log
    (o/(label+'-whole-job.log')).write_text(log)
    jobs.append(dict(label=label,run=run,job=job,status='completed',conclusion='success'))
    if label=='PCC':
        sign=[j for j in api if j['name']=='sign']; assert len(sign)==1 and sign[0]['conclusion']=='skipped'
        assert any('exit 2 = not covered is allowed' in step['name'] for step in j['steps'])
    else:
        rows[label]=records(log)
        for line in log.splitlines():
            if '{"claim_id":' in line: verdicts.append(json.loads(line[line.index('{"claim_id":'):]))
assert {k:len(v) for k,v in rows.items()}==dict(completed=17,V2=12,P1=13)
def omitted(rows):
    rows=json.loads(json.dumps(rows))
    for row in rows:
        methods=['baseline','candidate'] if row['kind']=='N4_COMPLETED_ATTEMPT' else ['public'] if row['kind']=='N4_PUBLIC_ATTEMPT' else []
        for method in methods:
            for phase in row['data'][method]['phases']: del phase['wall']
            row['data'][method]['stats']=[p for p in row['data'][method]['stats'] if p[0]!='wall_total']
    return canonical(rows)
assert omitted(rows['completed'])==omitted(json.loads((s/'ci_completed/expected-native.json').read_text()))
assert omitted(rows['P1'])==omitted(json.loads((s/'evidence/unit-acceptance-01/all-native-records.json').read_text()))
for prefix,name in [('N4_V2_','expected-native-v2.json'),('N4_RHO_','expected-native-rho.json')]:
    assert canonical([x for x in rows['V2'] if x['kind'].startswith(prefix)])==canonical(json.loads((s/'ci_v2'/name).read_text()))
spec=importlib.util.spec_from_file_location('original_pcc',r/'tools/pcc/pcc.py'); pcc=importlib.util.module_from_spec(spec); sys.modules[spec.name]=pcc; spec.loader.exec_module(pcc)
digests={}
for folder in ['lean-bindings-01','origin-lean-bindings-01','prime-field-bindings-02']:
    for binding in json.loads((s/'evidence'/folder/'claims.json').read_text()):
        c=json.loads((r/binding['claim_path']).read_text()); digests[c['id']]=pcc.claim_digest(c)
assert len(verdicts)==len(digests)==17 and set(digests)=={v['claim_id'] for v in verdicts}
for v in verdicts: assert v['verdict']=='pass' and not v['reasons'] and v['commit']==source and v['claim_sha256']==digests[v['claim_id']]
full=Path('/workspace/scratch/ct58-completed-full-01')
shutil.copytree(full/'driver/source',o/'source')
shutil.copyfile(full/'original-reference.sha256',o/'source/cryptanalysis/experiments/chained-transfer-public-target/ci_completed/reference-01.sha256')
assert sum(p.is_file() for p in (o/'source').rglob('*'))==484
for name,data in [('all-native-records.json',rows),('all17-exact-verdicts.json',verdicts),('original-PCC-canonical-digests.json',digests)]: (o/name).write_text(json.dumps(data,indent=2)+'\n')
shutil.copyfile(__file__,o/'original-collector.py')
meta=dict(at=datetime.now(timezone.utc).isoformat(),source=source,jobs=jobs,native_records=42,all42_original_native_JSON_match_except_ONLY_recorded_wall_walltotal_for_candidate_and_P1=True,raw_timings_retained=True,all17_original_canonical_PCC_digests_match=True,exact_verdicts='pass/unsigned',PCC_sign='legitimately skipped featurebranch',PCC_gate='success; explicitly allows notcovered exit2',whole_logs_API_and484_source_snapshots_retained=True,artifact_ZIP_downloaded=False,CI_guard_scope='successful original replay steps and complete original markers; standalone exit files not downloaded; separate localfull484 actual guards0',scope='correctness observations; not full formal geometry, cost advantage or signed execution')
(o/'plan.json').write_text(json.dumps(meta,indent=2)+'\n')
d=s/'evidence/completed-own-CI-01'; d.mkdir(); (d/'observation.json').write_text(json.dumps(meta,indent=2)+'\n')
for name in ['all-native-records.json','all17-exact-verdicts.json','original-PCC-canonical-digests.json']:
    raw=(o/name).read_bytes(); (d/(name+'.xz')).write_bytes(lzma.compress(raw))
for label in ['completed','V2','P1','PCC']:
    raw=(o/(label+'-whole-job.log')).read_bytes(); (d/(label+'-whole-job.log.xz')).write_bytes(lzma.compress(raw))
claim('Exact68feb independent CI: completed43445565169/131953969628, V2rho43445564907/131953968270, P143445564904/131953968746, PCC43445565067/131953969401 all SUCCESS. All42 native JSON match originals; ONLY candidate/P1 phases.wall and stats.wall_total excluded from equality, raw intact. All17 exact localPCC verdicts pass/currentcommit/original canonicaldigests. PCC gate explicitly allowsnotcovered2; sign legitimately skipped featurebranch. Whole4logs/API/484sources retained; CIguard inference successful original steps+complete markers, not downloaded standalone exitfiles/ZIP. Separate localfull484guards0/b40fec. No signed execution/fullformalgeometry/costadvantage.',d)
