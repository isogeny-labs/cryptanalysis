## IC benchmark vs baseline

Baseline `experiments/ic-bench/baseline/ci.csv`, tolerance 5%.

| cell | status | candidate | total ops (base → new) | ratio | queries (base → new) | wall s (new) | verdict |
|---|---|---|--:|--:|--:|--:|---|
| n13m3l3-geomtrace-s1-mxl-w1 | complete | changed | 58654499016 → 58654499016 | 1.0000 | 143 → 143 | 0.3 | changed, within tolerance |
| n13m3l3-geomtrace-s1-mxl-w2 | complete | changed | 47234894225 → 47234894225 | 1.0000 | 161 → 161 | 0.3 | changed, within tolerance |
| n13m3l3-geomtrace-s1-mxl-w3 | complete | changed | 43849256743 → 43849256743 | 1.0000 | 111 → 111 | 0.2 | changed, within tolerance |
| n13m3l3-prefix-s1-mxl-w1 | complete | changed | 86326223632 → 86326223632 | 1.0000 | 134 → 134 | 0.5 | changed, within tolerance |
| n13m3l3-prefix-s1-mxl-w2 | complete | changed | 70993461457 → 70993461457 | 1.0000 | 186 → 186 | 0.4 | changed, within tolerance |
| n13m3l3-prefix-s1-mxl-w3 | complete | changed | 69262898118 → 69262898118 | 1.0000 | 207 → 207 | 0.3 | changed, within tolerance |
| n13m3l3-random-s1-mxl-w1 | complete | changed | 42256058192 → 42256058192 | 1.0000 | 169 → 169 | 0.2 | changed, within tolerance |
| n13m3l3-random-s1-mxl-w2 | complete | changed | 149888873552 → 149888873552 | 1.0000 | 284 → 284 | 0.9 | changed, within tolerance |
| n13m3l3-random-s1-mxl-w3 | complete | changed | 106286997649 → 106286997649 | 1.0000 | 284 → 284 | 0.6 | changed, within tolerance |
| n19m2l5-geomtrace-s1-mxl-w1 | complete | changed | 528480335884 → 528480335884 | 1.0000 | 25739 → 25739 | 11.0 | changed, within tolerance |
| n19m2l5-prefix-s1-mxl-w1 | complete | changed | 922151340441 → 922151340441 | 1.0000 | 42748 → 42748 | 16.9 | changed, within tolerance |
| n19m2l5-random-s1-mxl-w1 | complete | changed | 817470704273 → 817470704273 | 1.0000 | 35670 → 35670 | 18.0 | changed, within tolerance |

Geometric mean total-operations ratio over 12 cells: **1.0000**

### Notes
- n13m3l3-geomtrace-s1-mxl-w1: candidate changed IC1N13Ckb1fb8PDP3xlRCsampleLAgaussTDpdpISO0h9cd5348f2b43 -> IC1N13Ckb1fb8PDP3xlRCsampleLAgaussTDpdpISO0hd9bcbde46555
- n13m3l3-geomtrace-s1-mxl-w2: candidate changed IC1N13Ckb1fb8PDP3xlRCsampleLAgaussTDpdpISO0h9cd5348f2b43 -> IC1N13Ckb1fb8PDP3xlRCsampleLAgaussTDpdpISO0hd9bcbde46555
- n13m3l3-geomtrace-s1-mxl-w3: candidate changed IC1N13Ckb1fb8PDP3xlRCsampleLAgaussTDpdpISO0h9cd5348f2b43 -> IC1N13Ckb1fb8PDP3xlRCsampleLAgaussTDpdpISO0hd9bcbde46555
- n13m3l3-prefix-s1-mxl-w1: candidate changed IC1N13Ckb1fb8PDP3xlRCsampleLAgaussTDpdpISO0hb34ead1a1d66 -> IC1N13Ckb1fb8PDP3xlRCsampleLAgaussTDpdpISO0h524f4167880e
- n13m3l3-prefix-s1-mxl-w2: candidate changed IC1N13Ckb1fb8PDP3xlRCsampleLAgaussTDpdpISO0hb34ead1a1d66 -> IC1N13Ckb1fb8PDP3xlRCsampleLAgaussTDpdpISO0h524f4167880e
- n13m3l3-prefix-s1-mxl-w3: candidate changed IC1N13Ckb1fb8PDP3xlRCsampleLAgaussTDpdpISO0hb34ead1a1d66 -> IC1N13Ckb1fb8PDP3xlRCsampleLAgaussTDpdpISO0h524f4167880e
- n13m3l3-random-s1-mxl-w1: candidate changed IC1N13Ckb1fb4PDP3xlRCsampleLAgaussTDpdpISO0h7e9e3a2574ab -> IC1N13Ckb1fb4PDP3xlRCsampleLAgaussTDpdpISO0hbc5dc0d58ac4
- n13m3l3-random-s1-mxl-w2: candidate changed IC1N13Ckb1fb4PDP3xlRCsampleLAgaussTDpdpISO0h7e9e3a2574ab -> IC1N13Ckb1fb4PDP3xlRCsampleLAgaussTDpdpISO0hbc5dc0d58ac4
- n13m3l3-random-s1-mxl-w3: candidate changed IC1N13Ckb1fb4PDP3xlRCsampleLAgaussTDpdpISO0h7e9e3a2574ab -> IC1N13Ckb1fb4PDP3xlRCsampleLAgaussTDpdpISO0hbc5dc0d58ac4
- n19m2l5-geomtrace-s1-mxl-w1: candidate changed IC1N19Ckb1fb32PDP2xlRCsampleLAgaussTDpdpISO0hd7e2a2df132a -> IC1N19Ckb1fb32PDP2xlRCsampleLAgaussTDpdpISO0h65679d7a4b79
- n19m2l5-prefix-s1-mxl-w1: candidate changed IC1N19Ckb1fb26PDP2xlRCsampleLAgaussTDpdpISO0hcd25859bf666 -> IC1N19Ckb1fb26PDP2xlRCsampleLAgaussTDpdpISO0hb0547b900d30
- n19m2l5-random-s1-mxl-w1: candidate changed IC1N19Ckb1fb34PDP2xlRCsampleLAgaussTDpdpISO0h6b009bd3c886 -> IC1N19Ckb1fb34PDP2xlRCsampleLAgaussTDpdpISO0h4462e5b70bcb

### Result
**PASS**

